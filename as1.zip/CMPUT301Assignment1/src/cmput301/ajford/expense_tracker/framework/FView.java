package cmput301.ajford.expense_tracker.framework;

/**
 * @author Adam
 *
 * Source: https://github.com/abramhindle/FillerCreepForAndroid/blob/master/src/es/softwareprocess/fillercreep/FView.java (2015-01-31)
 */
public interface FView<M> {
	public void update(M model);
}
