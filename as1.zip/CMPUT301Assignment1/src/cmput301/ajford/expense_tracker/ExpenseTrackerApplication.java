/**
 * 
 */
package cmput301.ajford.expense_tracker;

import android.app.Application;

/**
 * @author Adam
 *
 * Based on https://github.com/abramhindle/FillerCreepForAndroid/blob/master/src/es/softwareprocess/fillercreep/FillerCreepApplication.java
 * from 2015-01-31
 */
public class ExpenseTrackerApplication extends Application {

}
